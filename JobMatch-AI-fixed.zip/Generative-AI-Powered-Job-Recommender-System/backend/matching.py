"""Rule-based job <-> candidate scoring."""
from typing import Any, Dict, List, Optional

from .skills import canonical

FEEDBACK_ADJUST = {"up": 3, "relevant": 3, "down": -8, "irrelevant": -8}


# Words that appear in almost every job title and say nothing about role fit.
_TITLE_STOPWORDS = {
    "senior", "junior", "lead", "principal", "staff", "associate", "sr", "jr", "the", "and", "for",
    "engineer", "developer", "specialist", "consultant", "manager", "analyst", "executive", "intern",
}


def _words(text: str) -> set:
    tokens = "".join(c.lower() if c.isalnum() else " " for c in text).split()
    return {w for w in tokens if len(w) >= 2 and w not in _TITLE_STOPWORDS}


def score_job(
    job: Dict[str, Any],
    candidate_skills: List[str],
    role: Optional[str] = None,
    location: Optional[str] = None,
    feedback: Optional[str] = None,
) -> Dict[str, Any]:
    cand = {canonical(s) for s in candidate_skills}
    required = job.get("requiredSkills", [])
    matching = [s for s in required if canonical(s) in cand]
    missing = [s for s in required if canonical(s) not in cand]

    # Coverage of required skills (capped denominator so long skill lists aren't punished)
    coverage = len(matching) / max(1, min(len(required), 8)) if required else 0.0
    base = min(1.0, coverage) * 80

    role_bonus = 0
    if role and _words(role) & _words(job.get("title", "")):
        role_bonus = 12

    loc_bonus = 0
    if location and job.get("location"):
        city = location.split(",")[0].strip().lower()
        if city and city in job["location"].lower():
            loc_bonus = 8
        elif job.get("workType") == "Remote":
            loc_bonus = 4

    score = base + role_bonus + loc_bonus + FEEDBACK_ADJUST.get(feedback or "", 0)
    score = max(0, min(100, round(score)))

    if required:
        reason = f"{len(matching)} of {len(required)} detected skills match your profile"
        if missing:
            reason += f"; consider learning {', '.join(missing[:3])}"
        reason += "."
    else:
        reason = "No specific skills detected in this posting; score is based on title and location."

    return {**job, "matchScore": score, "matchingSkills": matching,
            "missingSkills": missing, "recommendationReason": reason}
