"""One provider per Apify actor. Actor ids/inputs come from the project's api.txt."""
from dataclasses import dataclass
from typing import Any, Callable, Dict, FrozenSet, List, Optional
from urllib.parse import urlencode

from .base import normalize_all, run_actor

COUNTRY_NAMES = {"in": "India", "us": "United States", "gb": "United Kingdom", "ca": "Canada",
                 "au": "Australia", "de": "Germany", "sg": "Singapore", "ae": "United Arab Emirates"}


@dataclass
class Provider:
    key: str
    label: str
    actor_id: str
    build_input: Callable[[Dict[str, Any]], Dict[str, Any]]
    # ISO country codes this actor can search; None means "any country".
    countries: Optional[FrozenSet[str]] = None

    def supports(self, country: str) -> bool:
        return self.countries is None or country.lower() in self.countries

    def fetch_raw(self, params: Dict[str, Any]) -> List[Dict[str, Any]]:
        return run_actor(self.key, self.actor_id, self.build_input(params), params["limit"])

    def fetch(self, params: Dict[str, Any]) -> List[Dict[str, Any]]:
        return normalize_all(self.label, self.fetch_raw(params))


def _linkedin_input(p: Dict[str, Any]) -> Dict[str, Any]:
    query = {"keywords": p["query"], "location": p.get("location") or COUNTRY_NAMES.get(p["country"], ""),
             "position": 1, "pageNum": 0}
    if p.get("work_type") == "Remote":
        query["f_WT"] = "2"
    elif p.get("work_type") == "Hybrid":
        query["f_WT"] = "3"
    elif p.get("work_type") == "On-site":
        query["f_WT"] = "1"
    return {
        "urls": [f"https://www.linkedin.com/jobs/search/?{urlencode(query)}"],
        "datePosted": "anyTime",
        "companyIds": [],
        "under10Applicants": False,
        "autoConvertToAiSearch": True,
        "scrapeCompany": True,
        "limitPerSource": p["limit"],
        "splitByLocation": False,
    }


def _indeed_input(p: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "country": p["country"],
        "title": p["query"],
        "location": p.get("location") or "",
        "limit": p["limit"],
        "datePosted": "7",
    }


def _monster_input(p: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "query": p["query"],
        "startUrls": [],
        "country": "US",  # the actor only supports Monster US (other portals were discontinued)
        "location": p.get("location") or "",
        "radius": 30,
        "maxResults": p["limit"],
        "descriptionMaxLength": 0,
        "compact": False,
        "incrementalMode": False,
        "skipReposts": False,
        "notificationLimit": 5,
        "notifyOnlyChanges": False,
        "includeRunMetadata": True,
        "descriptionFormat": "all",
        "excludeEmptyFields": False,
        "emitUnchanged": False,
        "emitExpired": False,
    }


PROVIDERS: Dict[str, Provider] = {
    "linkedin": Provider("linkedin", "LinkedIn", "hKByXkMQaC5Qt9UMN", _linkedin_input),
    "indeed": Provider("indeed", "Indeed", "TrtlecxAsNRbKl1na", _indeed_input),
    "monster": Provider("monster", "Monster", "9d4mn9SVh5WvvtLii", _monster_input, countries=frozenset({"us"})),
}
