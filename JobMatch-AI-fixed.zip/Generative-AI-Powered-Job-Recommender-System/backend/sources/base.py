"""Shared helpers: Apify REST runner + defensive field normalisation."""
import hashlib
import html
import re
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

import httpx

from ..config import APIFY_TIMEOUT_SECS, scrub, token_for
from ..skills import detect_work_type, extract_experience, extract_skills

APIFY_BASE = "https://api.apify.com/v2"


class SourceError(RuntimeError):
    pass


def run_actor(source: str, actor_id: str, run_input: Dict[str, Any], limit: int) -> List[Dict[str, Any]]:
    """Run an Apify actor synchronously and return its dataset items.

    Uses the run-sync-get-dataset-items endpoint (max ~300s). The token is sent as a
    Bearer header so it never appears in URLs or logs.
    """
    token = token_for(source)
    if not token:
        raise SourceError(f"No Apify token configured for '{source}'. Set APIFY_TOKEN in .env.")
    url = f"{APIFY_BASE}/acts/{actor_id}/run-sync-get-dataset-items"
    try:
        with httpx.Client(timeout=APIFY_TIMEOUT_SECS + 20) as client:
            res = client.post(
                url,
                params={"timeout": APIFY_TIMEOUT_SECS, "limit": limit, "format": "json", "clean": "true"},
                headers={"Authorization": f"Bearer {token}"},
                json=run_input,
            )
    except httpx.HTTPError as exc:
        raise SourceError(scrub(f"Network error talking to Apify: {exc}")) from exc

    if res.status_code in (200, 201):
        try:
            data = res.json()
        except ValueError as exc:
            raise SourceError(f"Apify returned a non-JSON response: {scrub(res.text[:200])}") from exc
        return data if isinstance(data, list) else []
    hint = {
        401: "Token rejected by Apify (check APIFY_TOKEN).",
        402: "Apify account is out of credits or the actor needs a paid plan.",
        403: "This token is not allowed to run that actor.",
        404: "Actor not found (the actor id may have changed).",
        408: "Actor run exceeded the time limit; try a smaller limit.",
    }.get(res.status_code, f"Apify returned HTTP {res.status_code}.")
    raise SourceError(scrub(f"{hint} {res.text[:200]}"))


# ---- field helpers ------------------------------------------------------------
def pick(item: Dict[str, Any], *paths: str) -> Any:
    """First non-empty value among dotted key paths (keys matched case-insensitively)."""
    for path in paths:
        cur: Any = item
        for part in path.split("."):
            if isinstance(cur, dict):
                if part in cur:
                    cur = cur[part]
                else:
                    key = next((k for k in cur if k.lower() == part.lower()), None)
                    cur = cur[key] if key is not None else None
            else:
                cur = None
            if cur is None:
                break
        if cur not in (None, "", [], {}):
            return cur
    return None


def as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return ", ".join(t for t in (as_text(v) for v in value) if t)
    if isinstance(value, dict):
        for k in ("name", "title", "text", "formatted", "formattedAddress", "formattedAddressShort",
                  "label", "display"):
            if value.get(k):
                return as_text(value[k])
        parts = [as_text(value.get(k)) for k in ("city", "state", "admin1Code", "region", "country", "countryName")]
        return ", ".join(p for p in parts if p)
    return str(value)


def strip_html(text: str) -> str:
    text = re.sub(r"<\s*(br|/p|/li|/div|/h\d)\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"<li[^>]*>", "• ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"[ \t]+", " ", text)
    return re.sub(r"\n\s*\n+", "\n", text).strip()


def format_salary(value: Any) -> str:
    if value in (None, "", [], {}):
        return "Not disclosed"
    if isinstance(value, dict):
        lo = value.get("min") or value.get("minimum") or value.get("from")
        hi = value.get("max") or value.get("maximum") or value.get("to")
        cur = str(value.get("currency") or value.get("currencyCode") or "")
        per = value.get("period") or value.get("unit") or value.get("unitOfWork") or value.get("type") or ""
        if cur.isalpha() and len(cur) > 1:  # ISO code such as "INR" -> "INR 12,000"
            cur += " "
        if lo or hi:
            rng = " - ".join(f"{cur}{int(float(x)):,}" if str(x).replace('.', '', 1).isdigit() else str(x)
                             for x in (lo, hi) if x)
            return f"{rng} / {per}".strip(" /") if per else rng
        return as_text(value) or "Not disclosed"
    text = as_text(value)
    if isinstance(value, list):
        text = " - ".join(t for t in (as_text(v) for v in value) if t)
    return text or "Not disclosed"


def relative_time(value: Any) -> str:
    if value in (None, ""):
        return "Recently"
    if isinstance(value, (int, float)):
        ts = value / 1000 if value > 1e11 else value
        dt = datetime.fromtimestamp(ts, tz=timezone.utc)
    else:
        text = str(value).strip()
        try:
            dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
        except ValueError:
            return text[:24]  # already human-readable, e.g. "3 days ago"
    secs = max(0, (datetime.now(timezone.utc) - dt).total_seconds())
    if secs < 3600:
        return f"{max(1, int(secs // 60))}m ago"
    if secs < 86400:
        return f"{int(secs // 3600)}h ago"
    if secs < 14 * 86400:
        return f"{int(secs // 86400)}d ago"
    if secs < 60 * 86400:
        return f"{int(secs // (7 * 86400))}w ago"
    return dt.strftime("%d %b %Y")


def normalize_item(source_label: str, item: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Map a raw actor record onto the job shape the UI expects."""
    title = as_text(pick(item, "title", "jobTitle", "positionName", "position", "job_title", "name"))
    company = as_text(pick(item, "companyName", "company", "company_name", "employer", "employerName", "company.name"))
    if not title:
        return None
    location = as_text(pick(item, "location", "jobLocation", "formattedLocation", "job_location", "city", "place"))
    url = as_text(pick(item, "jobUrl", "link", "url", "applyUrl", "jobLink", "viewJobLink", "job_url", "externalApplyLink"))

    raw_desc = as_text(pick(item, "descriptionText", "descriptionPlain", "description", "jobDescription",
                            "descriptionHtml", "description_html", "snippet", "summary"))
    description = strip_html(raw_desc) if "<" in raw_desc else raw_desc

    remote_flag = pick(item, "isRemote", "remote", "is_remote")
    work_type = detect_work_type(
        as_text(pick(item, "workplaceType", "workType", "work_type", "remoteType")), title, location,
        description[:1500], flag=remote_flag if isinstance(remote_flag, bool) else None,
    )

    blob = f"{title}\n{description}"
    skills = extract_skills(blob)
    uid = hashlib.sha1(
        (url or f"{source_label}|{title}|{company}|{location}").lower().encode()
    ).hexdigest()[:12]

    return {
        "id": f"live-{uid}",
        "title": title,
        "company": company or "Company not listed",
        "location": location or "Not specified",
        "experience": extract_experience(blob, title),
        "workType": work_type,
        "salary": format_salary(pick(item, "salary", "salaryInfo", "salaryText", "salary_text",
                                     "compensation", "baseSalary", "salaryRange", "pay")),
        "matchScore": 0,
        "description": (description[:900] + "…") if len(description) > 900 else description or "No description provided.",
        "requiredSkills": skills,
        "matchingSkills": [],
        "missingSkills": skills[:],
        "recommendationReason": "",
        "source": source_label,
        "postedDate": relative_time(pick(item, "postedAt", "postedDate", "datePosted", "listedAt", "publishedAt",
                                         "datePublished", "posted", "postingDate", "date", "date_posted", "pubDate")),
        "url": url,
        "live": True,
    }


def normalize_all(source_label: str, items: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for item in items:
        if isinstance(item, dict):
            job = normalize_item(source_label, item)
            if job:
                out.append(job)
    return out
