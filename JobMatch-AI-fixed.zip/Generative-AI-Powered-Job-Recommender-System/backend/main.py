"""JobMatch AI backend: live job aggregation (Apify) + skill-based recommendations."""
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import db
from .config import DEFAULT_COUNTRY, configured_sources, scrub
from .matching import score_job
from .seed import DEFAULT_PROFILE, SAMPLE_JOBS
from .sources.base import SourceError
from .sources.providers import PROVIDERS

app = FastAPI(
    title="Generative AI Powered Job Recommender System",
    description="FastAPI backend for JobMatch AI: live multi-board jobs + skill-based recommendations.",
    version="3.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------- models
class RecommendationRequest(BaseModel):
    skills: List[str] = Field(default_factory=list)
    role: Optional[str] = None
    experience_years: Optional[float] = None
    location: Optional[str] = None
    work_type: Optional[str] = None


class FeedbackRequest(BaseModel):
    job_id: str
    feedback: str


class ApplicationRequest(BaseModel):
    job_id: str


class ApplicationStatusRequest(BaseModel):
    status: str


class CandidateProfile(BaseModel):
    name: str
    title: str
    location: str
    email: str
    phone: str
    skills: List[str] = Field(default_factory=list)


class RefreshRequest(BaseModel):
    query: str = Field(min_length=2, max_length=120)
    location: Optional[str] = Field(default=None, max_length=120)
    country: str = Field(default=DEFAULT_COUNTRY, pattern=r"^[A-Za-z]{2}$")
    work_type: Optional[str] = None
    sources: List[str] = Field(default_factory=lambda: list(PROVIDERS))
    limit: int = Field(default=25, ge=1, le=100)


# ---------------------------------------------------------------- helpers
def get_profile() -> Dict[str, Any]:
    return db.kv_get("profile", DEFAULT_PROFILE)


def get_feedback() -> Dict[str, str]:
    return db.kv_get("feedback", {})


def all_jobs() -> tuple[List[Dict[str, Any]], str]:
    """Live jobs if any have been fetched, otherwise the flagged sample set."""
    live = db.list_jobs()
    return (live, "live") if live else (SAMPLE_JOBS, "sample")


def find_job(job_id: str) -> Optional[Dict[str, Any]]:
    return db.get_job(job_id) or next((j for j in SAMPLE_JOBS if j["id"] == job_id), None)


def scored(jobs, skills, role=None, location=None) -> List[Dict[str, Any]]:
    fb = get_feedback()
    return [score_job(j, skills, role, location, fb.get(j["id"])) for j in jobs]


# ---------------------------------------------------------------- basic
@app.get("/")
def home():
    return {
        "status": "running",
        "message": "Welcome to the Generative AI Powered Job Recommender System!",
        "version": app.version,
        "frontend": "/app/",
        "api_docs": "/docs",
        "health_check": "/api/health",
    }


@app.get("/api/health")
def health_check():
    jobs, mode = all_jobs()
    return {
        "status": "ok",
        "service": "job-recommender-api",
        "mode": mode,
        "jobs_loaded": len(jobs),
        "sources_configured": configured_sources(),
    }


@app.get("/api/sources")
def get_sources():
    """Which job boards can be queried (token present). Never returns the tokens themselves."""
    cfg = configured_sources()
    return {
        "status": "success",
        "sources": [{"key": k, "label": p.label, "configured": cfg.get(k, False)} for k, p in PROVIDERS.items()],
        "default_country": DEFAULT_COUNTRY,
    }


# ---------------------------------------------------------------- jobs
@app.get("/api/jobs")
def get_jobs(
    search: Optional[str] = None,
    work_type: Optional[str] = None,
    experience: Optional[str] = None,
    source: Optional[str] = None,
):
    jobs, mode = all_jobs()
    profile = get_profile()
    jobs = scored(jobs, profile["skills"], profile["title"], profile["location"])

    if search:
        q = search.strip().lower()
        jobs = [j for j in jobs if q in j["title"].lower() or q in j["company"].lower()
                or any(q in s.lower() for s in j["requiredSkills"])]
    if work_type and work_type != "All":
        jobs = [j for j in jobs if j["workType"] == work_type]
    if experience and experience != "All":
        jobs = [j for j in jobs if j["experience"] == experience]
    if source and source != "All":
        jobs = [j for j in jobs if j["source"].lower() == source.lower()]

    jobs.sort(key=lambda j: j["matchScore"], reverse=True)
    return {"status": "success", "mode": mode, "total": len(jobs), "jobs": jobs}


@app.delete("/api/jobs")
def clear_live_jobs():
    db.clear_jobs()
    return {"status": "success", "message": "Stored live jobs cleared; sample data will be shown."}


# ---- live refresh (background; scraping takes 30-120s per source) ----------------
RUNS: Dict[str, Dict[str, Any]] = {}
_RUNS_LOCK = threading.Lock()


def _run_refresh(run_id: str, req: RefreshRequest) -> None:
    params = {"query": req.query.strip(), "location": (req.location or "").strip(),
              "country": req.country.lower(), "work_type": req.work_type, "limit": req.limit}

    def work(key: str) -> None:
        state = RUNS[run_id]["sources"][key]
        state["status"] = "running"
        try:
            jobs = PROVIDERS[key].fetch(params)
            db.upsert_jobs(jobs)
            state.update(status="done", count=len(jobs))
        except SourceError as exc:
            state.update(status="error", error=scrub(str(exc)))
        except Exception as exc:  # never let one source break the others
            state.update(status="error", error=scrub(f"{type(exc).__name__}: {exc}"))

    threads = [threading.Thread(target=work, args=(k,), daemon=True) for k in req.sources]
    try:
        for t in threads:
            t.start()
        for t in threads:
            t.join()
    finally:  # even on an unexpected failure the run must leave the "running" state
        with _RUNS_LOCK:
            run = RUNS.get(run_id)
            if run is None:  # evicted from the bounded run table
                return
            for st in run["sources"].values():
                if st["status"] in ("queued", "running"):
                    st.update(status="error", error="Source did not finish.")
            run["total"] = sum(s.get("count", 0) for s in run["sources"].values())
            run["status"] = "done" if run["total"] or not all(
                s["status"] == "error" for s in run["sources"].values()) else "error"
            run["finished"] = time.time()


@app.post("/api/jobs/refresh")
def refresh_jobs(req: RefreshRequest):
    cfg = configured_sources()
    sources = [s for s in dict.fromkeys(req.sources) if s in PROVIDERS]
    if not sources:
        raise HTTPException(400, f"Choose at least one source of: {', '.join(PROVIDERS)}")
    # Some actors only cover certain countries (Monster = US). Skip them instead of returning junk.
    unsupported = [s for s in sources if not PROVIDERS[s].supports(req.country)]
    sources = [s for s in sources if s not in unsupported]
    if not sources:
        raise HTTPException(
            400,
            f"{', '.join(PROVIDERS[s].label for s in unsupported)} does not support country "
            f"'{req.country.upper()}'. Pick another job board or change the country.",
        )
    missing = [s for s in sources if not cfg.get(s)]
    if len(missing) == len(sources):
        raise HTTPException(
            400,
            "No Apify token configured. Copy .env.example to .env, set APIFY_TOKEN, and restart the server.",
        )
    sources = [s for s in sources if cfg.get(s)]
    req.sources = sources

    run_id = uuid.uuid4().hex[:10]
    with _RUNS_LOCK:
        # keep memory bounded
        for old in sorted(RUNS, key=lambda r: RUNS[r]["started"])[:-20]:
            RUNS.pop(old, None)
        RUNS[run_id] = {
            "run_id": run_id, "status": "running", "started": time.time(), "total": 0,
            "skipped_no_token": missing, "skipped_unsupported_country": unsupported,
            "sources": {s: {"status": "queued", "count": 0} for s in sources},
        }
    threading.Thread(target=_run_refresh, args=(run_id, req), daemon=True).start()
    return {"status": "started", "run_id": run_id, "sources": sources,
            "skipped_no_token": missing, "skipped_unsupported_country": unsupported}


@app.get("/api/jobs/refresh/{run_id}")
def refresh_status(run_id: str):
    run = RUNS.get(run_id)
    if not run:
        raise HTTPException(404, "Unknown run id.")
    return {**run, "elapsed": round(time.time() - run["started"])}


@app.get("/api/sources/{source}/sample")
def source_sample(source: str, query: str = "python developer", location: str = "", country: str = DEFAULT_COUNTRY):
    """Developer aid: run one actor with limit=3 and return RAW + normalised items.

    Use this once to confirm the real field names each actor returns. Costs Apify credits.
    """
    provider = PROVIDERS.get(source)
    if not provider:
        raise HTTPException(404, f"Unknown source. Use one of: {', '.join(PROVIDERS)}")
    if not configured_sources().get(source):
        raise HTTPException(400, "No Apify token configured for this source.")
    params = {"query": query, "location": location, "country": country.lower(), "work_type": None, "limit": 3}
    try:
        raw = provider.fetch_raw(params)
    except SourceError as exc:
        raise HTTPException(502, scrub(str(exc)))
    from .sources.base import normalize_all
    return {"source": source, "raw_count": len(raw), "raw": raw, "normalized": normalize_all(provider.label, raw)}


# ---------------------------------------------------------------- recommendations
@app.post("/api/recommend")
def recommend_jobs(request: RecommendationRequest):
    profile = get_profile()
    skills = request.skills or profile["skills"]
    jobs, mode = all_jobs()
    recs = scored(jobs, skills, request.role, request.location)
    if request.work_type and request.work_type != "All":
        recs = [r for r in recs if r["workType"] == request.work_type]
    recs.sort(key=lambda r: r["matchScore"], reverse=True)
    return {
        "status": "success",
        "mode": mode,
        "message": "Recommendations generated successfully.",
        "user_profile": {"skills": skills, "role": request.role, "experience_years": request.experience_years,
                         "location": request.location, "work_type": request.work_type},
        "total_recommendations": len(recs),
        "recommendations": recs,
    }


# ---------------------------------------------------------------- profile
@app.get("/api/profile")
def read_profile():
    return {"status": "success", "profile": get_profile()}


@app.put("/api/profile")
def update_profile(profile: CandidateProfile):
    db.kv_set("profile", profile.model_dump())
    return {"status": "success", "message": "Candidate profile updated.", "profile": profile.model_dump()}


# ---------------------------------------------------------------- applications
@app.get("/api/applications")
def get_applications():
    apps = db.list_applications()
    return {"status": "success", "total": len(apps), "applications": apps}


@app.post("/api/applications")
def create_application(request: ApplicationRequest):
    job = find_job(request.job_id)
    if not job:
        raise HTTPException(404, "Job not found.")
    existing = db.application_for_job(job["id"])
    if existing:
        return {"status": "success", "message": "Application already exists.", "application": existing}
    application = {
        "id": f"app-{int(datetime.now().timestamp() * 1000)}",
        "jobId": job["id"],
        "jobTitle": job["title"],
        "company": job["company"],
        "appliedDate": datetime.now().strftime("%Y-%m-%d"),
        "status": "Applied",
        "notes": "Application page opened. Finish applying on the job site, then update the status here.",
        "url": job.get("url", ""),
    }
    db.save_application(application)
    return {"status": "success", "message": "Application created successfully.", "application": application}


@app.patch("/api/applications/{application_id}")
def update_application_status(application_id: str, request: ApplicationStatusRequest):
    valid = ["Applied", "Reviewing", "Interviewing", "Offered", "Rejected"]
    if request.status not in valid:
        raise HTTPException(400, f"Invalid application status. Use one of: {valid}")
    application = db.get_application(application_id)
    if not application:
        raise HTTPException(404, "Application not found.")
    application["status"] = request.status
    db.save_application(application)
    return {"status": "success", "message": "Application status updated.", "application": application}


# ---------------------------------------------------------------- feedback
@app.post("/api/feedback")
def submit_feedback(request: FeedbackRequest):
    if request.feedback not in {"up", "down", "relevant", "irrelevant"}:
        raise HTTPException(400, "Feedback must be 'up', 'down', 'relevant' or 'irrelevant'.")
    if not find_job(request.job_id):
        raise HTTPException(404, "Job not found.")
    fb = get_feedback()
    fb[request.job_id] = request.feedback
    db.kv_set("feedback", fb)
    return {"status": "success", "message": "Feedback recorded.", "job_id": request.job_id, "feedback": request.feedback}


# ---------------------------------------------------------------- MCP-style pipeline
MCP_TOOLS = [
    {"id": "mcp-1", "name": "Job Search Tool", "description": "Queries live multi-board job vacancies (Apify)", "status": "active", "endpoint": "mcp://jobs/search"},
    {"id": "mcp-2", "name": "Job Details Extractor", "description": "Extracts skills, experience and work type from postings", "status": "active", "endpoint": "mcp://jobs/details"},
    {"id": "mcp-3", "name": "Candidate Fetcher", "description": "Fetches candidate metadata and skills", "status": "active", "endpoint": "mcp://candidate/profile"},
    {"id": "mcp-4", "name": "Matching Vector Engine", "description": "Scores skill overlap between candidate and job", "status": "active", "endpoint": "mcp://matching/compute"},
    {"id": "mcp-5", "name": "Recommendation Ranker", "description": "Ranks recommendations using match score and feedback", "status": "active", "endpoint": "mcp://recommendations/rank"},
    {"id": "mcp-6", "name": "Resume Parser", "description": "Extracts skills from PDF resumes (not implemented)", "status": "idle", "endpoint": "mcp://parser/resume"},
    {"id": "mcp-7", "name": "Application Sync Manager", "description": "Tracks application status", "status": "active", "endpoint": "mcp://applications/sync"},
    {"id": "mcp-8", "name": "ML Feedback Engine", "description": "Applies thumbs up/down feedback to ranking", "status": "active", "endpoint": "mcp://feedback/ingest"},
]


@app.get("/api/mcp/tools")
def get_mcp_tools():
    return {"status": "success", "total_tools": len(MCP_TOOLS),
            "active_tools": sum(t["status"] == "active" for t in MCP_TOOLS), "tools": MCP_TOOLS}


@app.post("/api/mcp/pipeline")
def run_mcp_pipeline():
    """Runs the real scoring pipeline over stored data and reports what it did."""
    profile = get_profile()
    jobs, mode = all_jobs()
    ranked = sorted(scored(jobs, profile["skills"], profile["title"], profile["location"]),
                    key=lambda r: r["matchScore"], reverse=True)
    sources = sorted({j["source"] for j in jobs})
    top = ranked[0] if ranked else None
    steps = [
        {"tool": "Candidate Fetcher", "message": f'Loaded profile for "{profile["name"]}" ({profile["location"]}) with {len(profile["skills"])} skills'},
        {"tool": "Job Search Tool", "message": f"{len(jobs)} {'live' if mode == 'live' else 'sample'} jobs available from {', '.join(sources) or 'no sources'}"},
        {"tool": "Job Details Extractor", "message": f"Detected {sum(len(j['requiredSkills']) for j in jobs)} skill requirements across postings"},
        {"tool": "Matching Vector Engine", "message": "Computed skill overlap, title and location fit for every job"},
        {"tool": "Recommendation Ranker", "message": (f'Top match: "{top["title"]}" at {top["company"]} ({top["matchScore"]}%)' if top else "Nothing to rank yet")},
        {"tool": "Application Sync Manager", "message": f"{len(db.list_applications())} applications tracked"},
    ]
    return {"status": "success", "protocol": "JSON-RPC 2.0 (simulated)", "message": "Pipeline executed.",
            "active_tools": sum(t["status"] == "active" for t in MCP_TOOLS), "steps": steps}


# ---------------------------------------------------------------- frontend
_here = Path(__file__).resolve().parent
for _candidate in (_here.parent / "frontend", _here / "frontend"):
    if (_candidate / "index.html").is_file():
        app.mount("/app", StaticFiles(directory=_candidate, html=True), name="frontend")
        break


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
