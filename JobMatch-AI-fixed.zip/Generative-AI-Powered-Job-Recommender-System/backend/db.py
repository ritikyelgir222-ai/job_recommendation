"""Tiny SQLite persistence layer (jobs, applications, profile, feedback)."""
import json
import sqlite3
import time
from contextlib import contextmanager
from typing import Any, Dict, List, Optional

from .config import DB_PATH

_SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY, source TEXT, payload TEXT NOT NULL, fetched_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS applications (
    id TEXT PRIMARY KEY, job_id TEXT, payload TEXT NOT NULL, created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


@contextmanager
def _conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=30)
    try:
        con.execute("PRAGMA journal_mode=WAL")  # background fetch threads write while the UI reads
        con.executescript(_SCHEMA)
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


# ---- jobs -------------------------------------------------------------------
def upsert_jobs(jobs: List[Dict[str, Any]]) -> int:
    now = time.time()
    with _conn() as con:
        con.executemany(
            "INSERT INTO jobs (id, source, payload, fetched_at) VALUES (?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, fetched_at=excluded.fetched_at",
            [(j["id"], j.get("source"), json.dumps(j), now) for j in jobs],
        )
    return len(jobs)


def list_jobs() -> List[Dict[str, Any]]:
    with _conn() as con:
        rows = con.execute("SELECT payload FROM jobs ORDER BY fetched_at DESC, rowid DESC").fetchall()
    return [json.loads(r[0]) for r in rows]


def get_job(job_id: str) -> Optional[Dict[str, Any]]:
    with _conn() as con:
        row = con.execute("SELECT payload FROM jobs WHERE id=?", (job_id,)).fetchone()
    return json.loads(row[0]) if row else None


def clear_jobs() -> None:
    with _conn() as con:
        con.execute("DELETE FROM jobs")


# ---- key/value (profile, feedback) -------------------------------------------
def kv_get(key: str, default: Any = None) -> Any:
    with _conn() as con:
        row = con.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
    return json.loads(row[0]) if row else default


def kv_set(key: str, value: Any) -> None:
    with _conn() as con:
        con.execute(
            "INSERT INTO kv (key, value) VALUES (?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value)),
        )


# ---- applications -----------------------------------------------------------
def list_applications() -> List[Dict[str, Any]]:
    with _conn() as con:
        rows = con.execute("SELECT payload FROM applications ORDER BY created_at DESC").fetchall()
    return [json.loads(r[0]) for r in rows]


def get_application(app_id: str) -> Optional[Dict[str, Any]]:
    with _conn() as con:
        row = con.execute("SELECT payload FROM applications WHERE id=?", (app_id,)).fetchone()
    return json.loads(row[0]) if row else None


def application_for_job(job_id: str) -> Optional[Dict[str, Any]]:
    with _conn() as con:
        row = con.execute("SELECT payload FROM applications WHERE job_id=?", (job_id,)).fetchone()
    return json.loads(row[0]) if row else None


def save_application(app: Dict[str, Any]) -> None:
    with _conn() as con:
        con.execute(
            "INSERT INTO applications (id, job_id, payload, created_at) VALUES (?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",
            (app["id"], app["jobId"], json.dumps(app), time.time()),
        )
