"""Runtime configuration. Secrets come from the environment / a local .env file."""
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

try:  # python-dotenv is optional but recommended
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
except ImportError:  # pragma: no cover
    pass

DB_PATH = Path(os.getenv("DB_PATH", ROOT / "backend" / "data" / "jobmatch.db"))

# Each source can use its own variable, falling back to the shared APIFY_TOKEN.
# The legacy names match the variable names used in the original api.txt.
_TOKEN_ENV = {
    "linkedin": ["APIFY_LINKEDIN_TOKEN", "APIFY_LINKEDIN_API"],
    "indeed": ["APIFY_INDEED_TOKEN", "INDEED_API_KEY"],
    "monster": ["APIFY_MONSTER_TOKEN", "MONSTER_API_KEY"],
}

DEFAULT_COUNTRY = os.getenv("DEFAULT_COUNTRY", "in")
APIFY_TIMEOUT_SECS = int(os.getenv("APIFY_TIMEOUT_SECS", "290"))  # sync endpoint caps at 300s


def _clean_token(value: str) -> str:
    """Accept a bare token, or a full URL that contains ?token=..."""
    value = value.strip().strip("\"'")
    match = re.search(r"token=([^&\s]+)", value)
    return match.group(1) if match else value


def token_for(source: str) -> str | None:
    for key in [*_TOKEN_ENV.get(source, []), "APIFY_TOKEN"]:
        raw = os.getenv(key)
        if raw and raw.strip() and "your_" not in raw.lower():
            return _clean_token(raw)
    return None


def configured_sources() -> dict:
    return {name: bool(token_for(name)) for name in _TOKEN_ENV}


def scrub(text: str) -> str:
    """Remove any configured token from a string before it is logged or returned."""
    for name in _TOKEN_ENV:
        tok = token_for(name)
        if tok:
            text = text.replace(tok, "***")
    return text
