"""Skill vocabulary + text extraction helpers (skills, experience, work type)."""
import re
from typing import Dict, List, Optional

# canonical name -> aliases (matched case-insensitively on word boundaries)
SKILLS: Dict[str, List[str]] = {
    "Python": ["python"], "Java": ["java"], "JavaScript": ["javascript", "js", "ecmascript"],
    "TypeScript": ["typescript"], "Go": ["golang"], "Rust": ["rust"], "C++": ["c++"], "C#": ["c#"],
    "SQL": ["sql"], "NoSQL": ["nosql"], "PostgreSQL": ["postgresql", "postgres"], "MySQL": ["mysql"],
    "MongoDB": ["mongodb", "mongo"], "Redis": ["redis"], "Elasticsearch": ["elasticsearch", "opensearch"],
    "Kafka": ["kafka"], "Spark": ["spark", "pyspark"], "Hadoop": ["hadoop"], "Airflow": ["airflow"],
    "dbt": ["dbt"], "Snowflake": ["snowflake"], "BigQuery": ["bigquery"], "Databricks": ["databricks"],
    "Pandas": ["pandas"], "NumPy": ["numpy"], "Scikit-learn": ["scikit-learn", "sklearn", "scikit learn"],
    "TensorFlow": ["tensorflow"], "PyTorch": ["pytorch", "torch"], "Keras": ["keras"],
    "XGBoost": ["xgboost"], "HuggingFace": ["huggingface", "hugging face"],
    "Transformers": ["transformers"], "LangChain": ["langchain"], "LlamaIndex": ["llamaindex", "llama-index", "llama index"],
    "OpenAI API": ["openai api", "openai", "gpt-4", "chatgpt"], "LLM": ["llm", "llms", "large language model", "large language models"],
    "RAG": ["rag", "retrieval augmented generation", "retrieval-augmented generation"],
    "Prompt Engineering": ["prompt engineering", "prompt design"], "Fine-tuning": ["fine-tuning", "fine tuning", "finetuning"],
    "LoRA": ["lora", "qlora", "peft"],
    "Vector DBs": ["vector db", "vector dbs", "vector database", "vector databases", "faiss", "weaviate", "milvus", "chroma", "chromadb", "qdrant", "pgvector"],
    "Pinecone": ["pinecone"], "Generative AI": ["generative ai", "genai", "gen ai"],
    "NLP": ["nlp", "natural language processing"], "Computer Vision": ["computer vision"],
    "MLOps": ["mlops"], "Machine Learning": ["machine learning", "ml"], "Deep Learning": ["deep learning"],
    "Data Science": ["data science"], "Statistics": ["statistics", "statistical"],
    "Data Pipelines": ["data pipeline", "data pipelines", "etl", "elt"],
    "vLLM": ["vllm"], "MCP": ["mcp", "model context protocol", "mcp tools", "mcp tool", "mcp endpoint"],
    "AI Agents": ["ai agents", "agentic", "ai agent", "multi-agent"],
    "FastAPI": ["fastapi"], "Flask": ["flask"], "Django": ["django"], "Spring Boot": ["spring boot", "springboot"],
    "Node.js": ["node.js", "nodejs", "node js"], "Express": ["express.js", "expressjs"],
    "React": ["react", "react.js", "reactjs"], "Next.js": ["next.js", "nextjs"], "Vue": ["vue", "vue.js"],
    "Angular": ["angular"], "Tailwind CSS": ["tailwind", "tailwindcss", "tailwind css"],
    "HTML": ["html", "html5"], "CSS": ["css", "css3"], "GraphQL": ["graphql"],
    "REST APIs": ["rest api", "rest apis", "restful", "rest"], "gRPC": ["grpc"],
    "Docker": ["docker"], "Kubernetes": ["kubernetes", "k8s"], "Terraform": ["terraform"],
    "AWS": ["aws", "amazon web services"], "Azure": ["azure"], "GCP": ["gcp", "google cloud"],
    "CI/CD": ["ci/cd", "cicd", "continuous integration"], "Git": ["git", "github", "gitlab"],
    "Linux": ["linux"], "Microservices": ["microservices", "microservice"],
    "Power BI": ["power bi", "powerbi"], "Tableau": ["tableau"], "Excel": ["excel"],
}

_ALIAS_TO_CANON: Dict[str, str] = {}
for _canon, _aliases in SKILLS.items():
    _ALIAS_TO_CANON[_canon.lower()] = _canon.lower()
    for _a in _aliases:
        _ALIAS_TO_CANON[_a.lower()] = _canon.lower()
# extra spellings candidates commonly use
_ALIAS_TO_CANON.update({"vector db": "vector dbs", "vector databases": "vector dbs",
                        "open ai api": "openai api", "generative ai": "generative ai"})


def canonical(skill: str) -> str:
    """Normalise a user/job skill string to a comparable key."""
    key = " ".join(skill.strip().lower().split())
    return _ALIAS_TO_CANON.get(key, key)


# Aliases that are ordinary English words (or too short to be safe) must appear with the
# capitalisation listed here, e.g. "REST" but not "the rest of the team".
_CASE_SENSITIVE_ALIASES: Dict[str, str] = {
    "rest": "REST", "ml": "ML", "rag": "RAG", "js": "JS", "excel": "Excel",
    "react": "React", "spark": "Spark", "torch": "Torch", "rust": "Rust",
}
# "Go" is only accepted next to words that make it clearly the language.
_GO_RE = re.compile(r"\bGo\b(?=[,;/ ]*(?:and |or |developer|engineer|lang|microservices|backend))")

_BOUNDARY = r"(?<![A-Za-z0-9+#.])(?:{})(?![A-Za-z0-9+#])"
_PATTERNS = []  # (canonical name, [compiled regexes])
for _canon, _aliases in SKILLS.items():
    _loose = [a for a in _aliases if a not in _CASE_SENSITIVE_ALIASES]
    _strict = [_CASE_SENSITIVE_ALIASES[a] for a in _aliases if a in _CASE_SENSITIVE_ALIASES]
    _alts = [re.escape(a) for a in sorted(_loose, key=len, reverse=True)]
    _parts = []
    if _alts:
        _parts.append(re.compile(_BOUNDARY.format("|".join(_alts)), re.I))
    if _strict:
        _parts.append(re.compile(_BOUNDARY.format("|".join(re.escape(a) for a in _strict))))
    if _canon == "Go":
        _parts.append(_GO_RE)
    _PATTERNS.append((_canon, _parts))


def extract_skills(text: str, limit: int = 14) -> List[str]:
    """Skills mentioned in `text`, ordered by first mention (earlier == more important)."""
    hits = []
    for canon, patterns in _PATTERNS:
        starts = [m.start() for m in (p.search(text) for p in patterns) if m]
        if starts:
            hits.append((min(starts), canon))
    hits.sort()
    return [canon for _, canon in hits[:limit]]


_EXP_RE = re.compile(
    r"(?<!\d)(\d{1,2})\s*(?:\+|plus)?\s*(?:(?:-|–|—|to)\s*(\d{1,2}))?\s*\+?\s*(?:years?|yrs?)\b", re.I)
_EXP_CONTEXT_RE = re.compile(r"experience|\bexp\b|expertise|background", re.I)


def extract_experience(text: str, title: str = "") -> str:
    """Return a bucket label ('0–2 yrs', '3–5 yrs', '6–9 yrs', '10+ yrs') or 'Not specified'.

    Only "N years" mentions that sit next to the word experience/expertise count, so boilerplate
    such as "we have been in business for 15 years" does not inflate the requirement.
    """
    years: Optional[int] = None
    for m in _EXP_RE.finditer(text):
        n = int(m.group(1))
        window = text[max(0, m.start() - 60): m.end() + 60]
        if 0 <= n <= 20 and _EXP_CONTEXT_RE.search(window):
            years = n if years is None else min(years, n)  # lowest stated minimum wins
    if years is None:
        if re.search(r"\b(intern|internship|fresher|graduate|entry[- ]level|junior|jr\.?)\b", f"{title} {text[:300]}", re.I):
            return "0–2 yrs"
        return "Not specified"
    if years <= 2:
        return "0–2 yrs"
    if years <= 5:
        return "3–5 yrs"
    if years <= 9:
        return "6–9 yrs"
    return "10+ yrs"


def detect_work_type(*texts: str, flag: Optional[bool] = None) -> str:
    if flag is True:
        return "Remote"
    blob = " ".join(t for t in texts if t).lower()
    if re.search(r"\bhybrid\b", blob):
        return "Hybrid"
    if re.search(r"\b(remote|work from home|wfh|work-from-home)\b", blob):
        return "Remote"
    if re.search(r"\b(on-?site|in[- ]office|in-person)\b", blob):
        return "On-site"
    return "Not specified"
