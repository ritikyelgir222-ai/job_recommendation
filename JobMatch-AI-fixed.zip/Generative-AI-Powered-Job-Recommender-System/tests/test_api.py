import time

from backend.sources import base, providers

LINKEDIN_ITEM = {"title": "GenAI Engineer", "companyName": "Globex", "location": "Pune",
                 "link": "https://www.linkedin.com/jobs/view/1",
                 "descriptionText": "3+ years experience with Python, LangChain and RAG."}
INDEED_ITEM = {"title": "Data Scientist", "employer": {"name": "Acme"}, "url": "https://in.indeed.com/viewjob?jk=2",
               "description": {"text": "Python, SQL, PyTorch. 2 years of experience."}}


def fake_run_actor(responses):
    def _run(source, actor_id, run_input, limit):
        value = responses[source]
        if isinstance(value, Exception):
            raise value
        return value
    return _run


def wait_for_run(client, run_id, timeout=10):
    end = time.time() + timeout
    while time.time() < end:
        run = client.get(f"/api/jobs/refresh/{run_id}").json()
        if run["status"] != "running":
            return run
        time.sleep(0.05)
    raise AssertionError("run did not finish")


def test_health_and_sample_mode(client):
    body = client.get("/api/health").json()
    assert body["mode"] == "sample" and body["jobs_loaded"] == 5
    jobs = client.get("/api/jobs").json()["jobs"]
    assert [j["matchScore"] for j in jobs] == sorted((j["matchScore"] for j in jobs), reverse=True)


def test_sources_never_expose_tokens(client):
    assert "test-token-123" not in client.get("/api/sources").text


def test_live_refresh_end_to_end(client, monkeypatch):
    monkeypatch.setattr(providers, "run_actor", fake_run_actor(
        {"linkedin": [LINKEDIN_ITEM], "indeed": [INDEED_ITEM]}))
    res = client.post("/api/jobs/refresh", json={"query": "ai engineer", "sources": ["linkedin", "indeed"]})
    assert res.status_code == 200
    run = wait_for_run(client, res.json()["run_id"])
    assert run["status"] == "done" and run["total"] == 2
    data = client.get("/api/jobs").json()
    assert data["mode"] == "live" and data["total"] == 2
    assert all(j["live"] for j in data["jobs"])


def test_one_failing_board_does_not_block_others(client, monkeypatch):
    monkeypatch.setattr(providers, "run_actor", fake_run_actor(
        {"linkedin": base.SourceError("boom test-token-123"), "indeed": [INDEED_ITEM]}))
    res = client.post("/api/jobs/refresh", json={"query": "python", "sources": ["linkedin", "indeed"]})
    run = wait_for_run(client, res.json()["run_id"])
    assert run["status"] == "done"
    assert run["sources"]["linkedin"]["status"] == "error"
    assert "test-token-123" not in run["sources"]["linkedin"]["error"]
    assert run["sources"]["indeed"]["count"] == 1


def test_all_boards_failing_marks_run_as_error(client, monkeypatch):
    err = base.SourceError("down")
    monkeypatch.setattr(providers, "run_actor", fake_run_actor({"linkedin": err, "indeed": err}))
    res = client.post("/api/jobs/refresh", json={"query": "python", "sources": ["linkedin", "indeed"]})
    assert wait_for_run(client, res.json()["run_id"])["status"] == "error"


def test_monster_is_skipped_outside_the_us(client, monkeypatch):
    monkeypatch.setattr(providers, "run_actor", fake_run_actor({"linkedin": [LINKEDIN_ITEM], "monster": []}))
    res = client.post("/api/jobs/refresh",
                      json={"query": "python", "country": "in", "sources": ["linkedin", "monster"]})
    body = res.json()
    assert body["sources"] == ["linkedin"] and body["skipped_unsupported_country"] == ["monster"]
    wait_for_run(client, body["run_id"])


def test_monster_only_outside_the_us_is_rejected(client):
    res = client.post("/api/jobs/refresh", json={"query": "python", "country": "in", "sources": ["monster"]})
    assert res.status_code == 400 and "does not support" in res.json()["detail"]


def test_monster_input_is_us_with_location():
    payload = providers.PROVIDERS["monster"].build_input(
        {"query": "python", "location": "Austin", "country": "us", "limit": 5})
    assert payload["country"] == "US" and payload["location"] == "Austin" and payload["maxResults"] == 5


def test_refresh_validation(client):
    assert client.post("/api/jobs/refresh", json={"query": "x"}).status_code == 422
    assert client.post("/api/jobs/refresh", json={"query": "python", "country": "india"}).status_code == 422
    assert client.post("/api/jobs/refresh", json={"query": "python", "sources": ["nope"]}).status_code == 400
    assert client.get("/api/jobs/refresh/unknown").status_code == 404


def test_clear_live_jobs_returns_to_sample(client, monkeypatch):
    monkeypatch.setattr(providers, "run_actor", fake_run_actor({"linkedin": [LINKEDIN_ITEM]}))
    run_id = client.post("/api/jobs/refresh", json={"query": "ai", "sources": ["linkedin"]}).json()["run_id"]
    wait_for_run(client, run_id)
    client.delete("/api/jobs")
    assert client.get("/api/jobs").json()["mode"] == "sample"


def test_job_filters(client):
    assert client.get("/api/jobs", params={"work_type": "Remote"}).json()["total"] == 2
    assert client.get("/api/jobs", params={"source": "linkedin"}).json()["total"] == 2
    assert client.get("/api/jobs", params={"search": "pinecone"}).json()["total"] == 1


def test_recommend_ranks_by_score(client):
    body = client.post("/api/recommend", json={"skills": ["Python", "PyTorch"], "role": "Data Scientist"}).json()
    scores = [r["matchScore"] for r in body["recommendations"]]
    assert scores == sorted(scores, reverse=True) and body["total_recommendations"] == 5


def test_profile_roundtrip_and_validation(client):
    profile = {"name": "A", "title": "T", "location": "L", "email": "e", "phone": "p", "skills": ["Go"]}
    assert client.put("/api/profile", json=profile).status_code == 200
    assert client.get("/api/profile").json()["profile"]["skills"] == ["Go"]
    assert client.put("/api/profile", json={"name": "A"}).status_code == 422


def test_application_lifecycle(client):
    created = client.post("/api/applications", json={"job_id": "job-1"}).json()["application"]
    again = client.post("/api/applications", json={"job_id": "job-1"}).json()
    assert again["application"]["id"] == created["id"]
    patched = client.patch(f"/api/applications/{created['id']}", json={"status": "Interviewing"})
    assert patched.json()["application"]["status"] == "Interviewing"
    assert client.patch(f"/api/applications/{created['id']}", json={"status": "Nope"}).status_code == 400
    assert client.post("/api/applications", json={"job_id": "missing"}).status_code == 404
    assert client.get("/api/applications").json()["total"] == 1


def test_feedback_changes_score(client):
    before = {j["id"]: j["matchScore"] for j in client.get("/api/jobs").json()["jobs"]}
    assert client.post("/api/feedback", json={"job_id": "job-2", "feedback": "down"}).status_code == 200
    after = {j["id"]: j["matchScore"] for j in client.get("/api/jobs").json()["jobs"]}
    assert after["job-2"] == max(0, before["job-2"] - 8)
    assert client.post("/api/feedback", json={"job_id": "job-2", "feedback": "meh"}).status_code == 400
    assert client.post("/api/feedback", json={"job_id": "zzz", "feedback": "up"}).status_code == 404


def test_mcp_pipeline_reports_steps(client):
    body = client.post("/api/mcp/pipeline").json()
    assert body["status"] == "success" and len(body["steps"]) == 6


def test_frontend_is_served_with_local_assets(client):
    assert client.get("/app/").status_code == 200
    assert "unpkg.com" not in client.get("/app/").text
    assert client.get("/app/vendor/lucide.min.js").status_code == 200
