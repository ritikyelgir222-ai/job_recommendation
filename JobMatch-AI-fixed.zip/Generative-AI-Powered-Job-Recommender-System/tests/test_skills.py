from backend.skills import canonical, detect_work_type, extract_experience, extract_skills


def test_extracts_common_skills_in_order_of_mention():
    skills = extract_skills("Build RAG apps in Python with FastAPI, Docker and AWS")
    assert skills == ["RAG", "Python", "FastAPI", "Docker", "AWS"]


def test_golang_alias_is_detected():
    assert "Go" in extract_skills("Backend work in Golang")


def test_ambiguous_english_words_are_not_skills():
    text = "You will react quickly, excel in a team and handle the rest of the work."
    assert extract_skills(text) == []


def test_capitalised_ambiguous_terms_are_skills():
    assert set(extract_skills("Experience with React, Excel, REST and Spark")) == {
        "React", "Excel", "REST APIs", "Spark"}


def test_java_is_not_javascript():
    assert extract_skills("Java developer") == ["Java"]
    assert extract_skills("JavaScript developer") == ["JavaScript"]


def test_canonical_aliases():
    assert canonical("Open AI API") == canonical("openai api")
    assert canonical("MCP Tools") == canonical("mcp")
    assert canonical("vector databases") == canonical("Vector DBs")


def test_experience_buckets_do_not_overlap():
    assert extract_experience("2 years of experience") == "0–2 yrs"
    assert extract_experience("4 years of experience") == "3–5 yrs"
    assert extract_experience("5+ years of experience") == "3–5 yrs"
    assert extract_experience("7 years experience") == "6–9 yrs"
    assert extract_experience("12 years of experience") == "10+ yrs"


def test_company_boilerplate_years_are_ignored():
    assert extract_experience("We have been in business for 15 years.") == "Not specified"


def test_junior_title_falls_back_to_entry_level():
    assert extract_experience("Great team", "Junior Data Analyst") == "0–2 yrs"


def test_work_type_detection():
    assert detect_work_type("Hybrid role, remote friendly") == "Hybrid"
    assert detect_work_type("Work from home") == "Remote"
    assert detect_work_type("on-site") == "On-site"
    assert detect_work_type("anything", flag=True) == "Remote"
    assert detect_work_type("nothing here") == "Not specified"
