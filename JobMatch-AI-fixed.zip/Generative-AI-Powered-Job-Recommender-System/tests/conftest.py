"""Test setup: isolate the DB and tokens *before* the backend is imported."""
import os
import tempfile
from pathlib import Path

_tmp = tempfile.mkdtemp(prefix="jobmatch-tests-")
os.environ["DB_PATH"] = str(Path(_tmp) / "test.db")
for _name in ("APIFY_TOKEN", "APIFY_LINKEDIN_API", "INDEED_API_KEY", "MONSTER_API_KEY",
              "APIFY_LINKEDIN_TOKEN", "APIFY_INDEED_TOKEN", "APIFY_MONSTER_TOKEN"):
    os.environ[_name] = "test-token-123"
os.environ["DEFAULT_COUNTRY"] = "in"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from backend import db  # noqa: E402
from backend.main import RUNS, app  # noqa: E402


@pytest.fixture()
def client():
    db.clear_jobs()
    RUNS.clear()
    with db._conn() as con:
        con.execute("DELETE FROM applications")
        con.execute("DELETE FROM kv")
    return TestClient(app)
