from backend.matching import score_job
from backend.sources.base import format_salary, normalize_item, relative_time

INDEED_ITEM = {
    "title": "ML Engineer",
    "employer": {"name": "Acme"},
    "location": {"city": "Pune", "admin1Code": "MH", "countryName": "India"},
    "description": {"html": "<p>5+ years of experience with Python and RAG</p>",
                    "text": "5+ years of experience with Python and RAG"},
    "baseSalary": {"currencyCode": "INR", "min": 1200000, "max": 2000000, "unitOfWork": "YEAR"},
    "datePublished": "2026-10-01T00:00:00Z",
    "url": "https://in.indeed.com/viewjob?jk=1",
}

LINKEDIN_ITEM = {
    "title": "Data Scientist", "companyName": "Globex", "location": "Mumbai, India",
    "link": "https://www.linkedin.com/jobs/view/1", "postedAt": "2026-10-02",
    "descriptionText": "Hybrid. 3+ years experience in Python, SQL and PyTorch.",
    "salaryInfo": ["₹10L", "₹15L"],
}


def test_indeed_shape_is_fully_mapped():
    job = normalize_item("Indeed", INDEED_ITEM)
    assert job["company"] == "Acme"
    assert job["location"] == "Pune, MH, India"
    assert job["salary"] == "INR 1,200,000 - INR 2,000,000 / YEAR"
    assert job["postedDate"] != "Recently"
    assert {"Python", "RAG", "Machine Learning"} <= set(job["requiredSkills"])
    assert job["experience"] == "3–5 yrs"
    assert job["url"].startswith("https://")


def test_linkedin_shape():
    job = normalize_item("LinkedIn", LINKEDIN_ITEM)
    assert job["workType"] == "Hybrid"
    assert job["salary"] == "₹10L - ₹15L"
    assert job["id"].startswith("live-")


def test_item_without_title_is_dropped():
    assert normalize_item("X", {"company": "NoTitle"}) is None


def test_same_url_gives_same_id():
    assert normalize_item("Indeed", INDEED_ITEM)["id"] == normalize_item("Indeed", INDEED_ITEM)["id"]


def test_format_salary_edge_cases():
    assert format_salary(None) == "Not disclosed"
    assert format_salary({"min": 10, "max": 20, "currency": "$", "period": "hour"}) == "$10 - $20 / hour"


def test_relative_time_handles_text_and_epoch():
    assert relative_time(None) == "Recently"
    assert relative_time("3 days ago") == "3 days ago"
    assert relative_time(0) .endswith("1970")


def test_score_rewards_skill_overlap_role_and_location():
    job = {"title": "AI Engineer", "location": "Pune", "workType": "Hybrid",
           "requiredSkills": ["Python", "RAG", "Docker"]}
    best = score_job(job, ["python", "rag", "docker"], "AI Developer", "Pune, MH")
    none = score_job(job, ["Java"], "Chef", "Delhi")
    assert best["matchScore"] == 100
    assert none["matchScore"] == 0
    assert best["missingSkills"] == [] and none["matchingSkills"] == []


def test_title_stopwords_do_not_create_false_role_fit():
    job = {"title": "Software Engineer", "location": "", "requiredSkills": []}
    assert score_job(job, [], "Data Engineer", None)["matchScore"] == 0


def test_two_letter_ai_counts_for_role_fit():
    job = {"title": "AI Lead", "location": "", "requiredSkills": []}
    assert score_job(job, [], "Generative AI Specialist", None)["matchScore"] == 12


def test_feedback_adjusts_score_and_is_clamped():
    job = {"title": "x", "location": "", "requiredSkills": ["Python"]}
    assert score_job(job, ["Python"], None, None, "down")["matchScore"] == 72
    assert score_job(job, ["Python"], None, None, "up")["matchScore"] == 83
    assert score_job({"title": "x", "requiredSkills": []}, [], None, None, "down")["matchScore"] == 0
